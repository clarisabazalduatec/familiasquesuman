package com.example.familiasquesuman

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import com.example.familiasquesuman.ui.theme.FamiliasQueSumanTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import com.example.familiasquesuman.data.SesionManager
import com.example.familiasquesuman.data.local.OnboardingPreferences
import com.example.familiasquesuman.data.repository.AuthRepository
import kotlinx.coroutines.launch
import com.example.familiasquesuman.ui.navigation.NavGraphFamilias
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Carga la sesión guardada (si el usuario marcó "Recordarme") y la valida con el backend.
        SesionManager.init(this)
        lifecycleScope.launch { AuthRepository().validarSesionGuardada() }

        val preferencias = OnboardingPreferences(this)
        val onboardingCompletado =
            preferencias.yaCompletoOnboarding()

        setContent {
            FamiliasQueSumanTheme {
                NavGraphFamilias(
                    mostrarOnboarding =  !onboardingCompletado,
                    marcarOnboardingVisto = {
                        preferencias.marcarComoCompletado()
                    }
                )
            }
        }
    }
}

